"""Router handoff tool package."""

